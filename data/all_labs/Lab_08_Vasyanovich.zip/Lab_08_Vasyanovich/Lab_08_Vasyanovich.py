from math import sqrt, pi, cos, sin
from mathutils import Matrix
from pyglet import image
from pyglet.gl import *
from pyglet.window import key
from pyglet.window import mouse
from OpenGL.GLUT import *
from numpy import array, cross
import json
import glfw
import OpenGL.GL.shaders as shader


window = pyglet.window.Window(1400, 1400, resizable = True)
window.set_minimum_size(144, 144)
gl.glClearColor(0, 0.6, 0.8, 1)
glutInit()
glfw.init()


Width = 1400
Height = 1400
ratio = 1
pos = array([0.0, 0.0, 0.0])
rot = [0, 0, 0]
isFramedMode = False
Horizontal = 13
Vertical = 13
Points = []
heightOfParaboloid = 1
P = 0.5
Q = 0.5
scale = 1.0
border = array([[-0.4, -0.4, -0.4], [1.1, 1.1, 1.1]])
figure = array([[-0.2, -sqrt(0.5) / 5.0, 0.4], [0.2, sqrt(0.5) / 5.0, 0.6]])
chess = image.load("wood5.bmp")
texture = chess.get_texture()


ambient_color = (GLfloat * 4)()
local_viewer = (GLfloat * 3)()
two_side = (GLfloat * 1)()
speed, vector, coordx, coordy, coordz, is_infinity_light, face, is_local, is_animated, is_lighted, is_textured, is_material = None, None, None, None, None, None, None, None, None, None, None, None
ambient, diffuse, specular, shininess, emission = (GLfloat * 4)(), (GLfloat * 4)(), (GLfloat * 4)(), 0, (GLfloat * 4)()
vShaderCode = """
	#version 330 core
    layout (location = 0) in vec3 position;
    layout (location = 1) in vec2 texture;
    layout (location = 1) in vec3 normal;

    uniform float rotateAngle_x = 0;
    uniform float rotateAngle_y = 0;
    uniform float rotateAngle_z = 0;
    uniform float scale = 1.0;
    uniform float translate_x = 0;
    uniform float translate_y = 0;
    uniform float translate_z = 0;

    uniform mat4 Projection = mat4(
            1, 0, 0, 0,
            0, 1, 0, 0,
            0, 0, 1, 0,
            0, 0, 0, 1
    );
    
    out vec3 Normal;
    out vec3 Position;
    out vec2 Texture;

        void main()
        {  
            mat3 rot_x = mat3(  
                1.0, 0.0, 0.0,
                0.0, cos(rotateAngle_x), -sin(rotateAngle_x),
                0.0, sin(rotateAngle_x), cos(rotateAngle_x)
            );

            mat3 rot_y = mat3(
                cos(rotateAngle_y), 0.0, sin(rotateAngle_y),
                0.0, 1.0, 0.0,
                -sin(rotateAngle_y), 0.0, cos(rotateAngle_y)
            );

            mat3 rot_z = mat3(
                cos(rotateAngle_z), -sin(rotateAngle_z), 0.0, 
                sin(rotateAngle_z), cos(rotateAngle_z), 0.0, 
                0.0, 0.0, 1.0
            );
			
			vec3 translate = vec3(translate_x, translate_y, translate_z);
            vec3 position2 = vec3(((((position * scale) * rot_x) * rot_y) * rot_z) + translate);
            vec4 position1 = vec4(position2, 1) * Projection;     
            gl_Position = position1;                 
            Normal = normalize((((normal * rot_x) * rot_y) * rot_z));
			Position = position2;
			Texture = texture;                                           
        }
"""

vFragmentCode = """
		#version 330 core
		out vec4 colorOut;
		void main() {
			colorOut = vec4(1.0f, 1.0f, 1.0f, 1.0f);
		}
"""
indices = []


class Shader:
	Program = 0

	def __init__(self):
		Program = shader.compileProgram(shader.compileShader(vShaderCode, GL_VERTEX_SHADER), shader.compileShader(vFragmentCode, GL_FRAGMENT_SHADER))

	def use(self):
		glUseProgram(self.Program)
		idv = GLuint(0)
		idi = GLuint(0)
		glGenBuffers(1, idv)
		glGenBuffers(1, idi)
		glBindBuffer(GL_ARRAY_BUFFER, idv)
		glBufferData(GL_ARRAY_BUFFER,
					 4 * len(Points),
					 Points,
					 GL_STREAM_DRAW)
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, idi)
		glBufferData(GL_ELEMENT_ARRAY_BUFFER,
					 4 * len(indices),
					 (GLuint * len(indices))(*indices),
					 GL_STREAM_DRAW)
		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, ctypes.c_void_p(0))
		glEnableVertexAttribArray(0)

	def projection(self, matrix):
		self.Program = shader.compileProgram(shader.compileShader(vShaderCode, GL_VERTEX_SHADER), shader.compileShader(vFragmentCode, GL_FRAGMENT_SHADER))
		glUseProgram(self.Program)
		Projection_location = glGetUniformLocation(self.Program, bytes('Projection', encoding='utf - 8'))
		glUniformMatrix4fv(Projection_location, 1, False, matrix)

	def update(self):
		self.Program = shader.compileProgram(shader.compileShader(vShaderCode, GL_VERTEX_SHADER), shader.compileShader(vFragmentCode, GL_FRAGMENT_SHADER))
		glUseProgram(self.Program)

		scale_location = glGetUniformLocation(self.Program, bytes('scale', encoding='utf - 8'))
		glUniform1f(scale_location, scale)

		rotateAngle_x_location = glGetUniformLocation(self.Program, bytes('rotateAngle_x', encoding='utf - 8'))
		glUniform1f(rotateAngle_x_location, rot[0])
		rotateAngle_y_location = glGetUniformLocation(self.Program, bytes('rotateAngle_y', encoding='utf - 8'))
		glUniform1f(rotateAngle_y_location, rot[1])
		rotateAngle_z_location = glGetUniformLocation(self.Program, bytes('rotateAngle_z', encoding='utf - 8'))
		glUniform1f(rotateAngle_z_location, rot[2])

		translate_x_location = glGetUniformLocation(self.Program, bytes('translate_x', encoding='utf - 8'))
		glUniform1f(translate_x_location, pos[0])
		translate_y_location = glGetUniformLocation(self.Program, bytes('translate_y', encoding='utf - 8'))
		glUniform1f(translate_y_location, pos[1])
		translate_z_location = glGetUniformLocation(self.Program, bytes('translate_z', encoding='utf - 8'))
		glUniform1f(translate_z_location, pos[2])


shaders = Shader()


def load():
	with open('data.txt') as json_file:
		global speed, vector, coordx, coordy, coordz, is_infinity_light, face, pname, ambient_color, local_viewer, two_side, parameters, is_local, is_animated, is_lighted, is_textured
		global ambient, diffuse, specular, shininess, emission, is_material
		result = json.load(json_file)
		is_textured = result['is_textured']
		is_lighted = result['is_lighted']
		is_animated = result['is_animated']
		speed = result['speed']
		vector = array([speed, speed, speed])
		coordx, coordy, coordz, is_infinity_light = result['light1'][0]['coordx'], result['light1'][0]['coordy'], \
													result['light1'][0]['coordz'], result['light1'][0][
														'is_infinity_light']
		ambient_color[0], ambient_color[1], ambient_color[2], ambient_color[3] = result['light3'][0]["ambient_color"][
																					 0], \
																				 result['light3'][0]["ambient_color"][
																					 1], \
																				 result['light3'][0]["ambient_color"][
																					 2], \
																				 result['light3'][0]["ambient_color"][3]
		is_local = result['light4'][0]["is_local"]
		local_viewer[0], local_viewer[1], local_viewer[2] = result['light4'][0]["local_viewer"][0], \
															result['light4'][0]["local_viewer"][1], \
															result['light4'][0]["local_viewer"][2]
		two_side[0] = result["light5"][0]["two_side"]
		face = result["light6"][0]['face']
		ambient[0], ambient[1], ambient[2], ambient[3] = result["ambient"][0], result["ambient"][1], result["ambient"][2], result["ambient"][3]
		diffuse[0], diffuse[1], diffuse[2], diffuse[3] = result["diffuse"][0], result["diffuse"][1], result["diffuse"][2], result["diffuse"][3]
		specular[0], specular[1], specular[2], specular[3] = result["specular"][0], result["specular"][1], result["specular"][2], result["specular"][3]
		shininess = result["shininess"]
		emission[0], emission[1], emission[2], emission[3] = result["emission"][0], result["emission"][1], result["emission"][2], result["emission"][3]
		is_material = result["is_material"]


def save():
	global speed, coordx, coordy, coordz, is_infinity_light, face, pname, ambient_color, local_viewer, two_side, parameters, is_local, is_animated, is_lighted, is_textured
	global ambient, diffuse, specular, shininess, emission, is_material
	data = {}

	data["is_textured"] = is_textured
	data['is_lighted'] = is_lighted
	data['is_animated'] = is_animated
	data['speed'] = speed
	data['light1'] = []
	data['light1'].append({
		'coordx': coordx,
		'coordy': coordy,
		'coordz': coordz,
		'is_infinity_light': is_infinity_light
	})
	data['light3'] = []
	data['light3'].append({
		'ambient_color': [ambient_color[0], ambient_color[1], ambient_color[2], ambient_color[3]]
	})
	data['light4'] = []
	data['light4'].append({
		'is_local': is_local,
		'local_viewer': [local_viewer[0], local_viewer[1], local_viewer[2]]
	})
	data['light5'] = []
	data['light5'].append({
		'two_side': two_side[0]
	})
	data['light6'] = []
	data['light6'].append({
		'face': face,
	})
	data["ambient"] = [] * 4
	data["ambient"][0], data["ambient"][1], data["ambient"][2], data["ambient"][3] = ambient[0], ambient[1], ambient[2], ambient[3]
	data["diffuse"] = [] * 4
	data["diffuse"][0], data["diffuse"][1], data["diffuse"][2], data["diffuse"][3] = diffuse[0], diffuse[1], diffuse[2], diffuse[3]
	data["specular"] = [] * 4
	data["specular"][0], data["specular"][1], data["specular"][2], data["specular"][3] = specular[0], specular[1], specular[2], specular[3]
	data["shininess"] = shininess
	data["emission"] = [] * 4
	data["emission"][0], data["emission"][1], data["emission"][2], data["emission"][3] = emission[0], emission[1], emission[2], emission[3]
	data["is_material"] = is_material
	with open('data.txt', 'w') as outfile:
		json.dump(data, outfile)


load()


def EllepticalParaboloid(framed):
	global Points, Horizontal, Vertical, heightOfParaboloid, indices
	indices = []

	for i in range(Vertical - 1):
		indices.extend([i, i + 1, Horizontal * Vertical])

	indices.extend([Vertical - 1, 0, Horizontal * Vertical])

	for j in range(Horizontal - 1):
		for i in range(Vertical - 1):
			indices.extend([j * Vertical + i, j * Vertical + i + 1, (j + 1) * Vertical + i + 1])
			indices.extend([(j + 1) * Vertical + i, (j + 1) * Vertical + i + 1, j * Vertical + i])
		indices.extend([j * Vertical + Vertical - 1, j * Vertical, (j + 1) * Vertical])
		indices.extend([(j + 1) * Vertical + Vertical - 1, (j + 1) * Vertical, j * Vertical + Vertical - 1])

	k = 1 + Horizontal * Vertical
	first_circle = k - 1 - Vertical
	last = int(len(Points) / 3) - 1
	last_circle = last - Vertical
	if Horizontal == 1:
		for i in range(Vertical - 1):
			indices.extend([i, i + 1, Vertical + 1])
		indices.extend([Vertical - 1, 0, Vertical + 1])
	else:
		for i in range(Vertical - 1):
			indices.extend([k + i, k + i + 1, last])
		indices.extend([k + Vertical - 1, k, last])
		for i in range(Horizontal - 2):
			for j in range(Vertical - 1):
				indices.extend([k + i * Vertical + j, k + i * Vertical + j + Vertical, k + i * Vertical + j + Vertical + 1])
				indices.extend([k + i * Vertical + j, k + i * Vertical + j + Vertical + 1, k + i * Vertical + j + 1])
			indices.extend([k + i * Vertical + Vertical - 1, k + i * Vertical + Vertical - 1 + Vertical, k + i * Vertical +Vertical])
			indices.extend([k + i * Vertical + Vertical - 1, k + i * Vertical + Vertical, k + i * Vertical])
		for i in range(Vertical - 1):
			indices.extend([last_circle + i, first_circle + i, first_circle + 1 + i])
			indices.extend([last_circle + i, first_circle + 1 + i, last_circle + i + 1])
		indices.extend([last_circle + Vertical - 1, first_circle + Vertical - 1, first_circle])
		indices.extend([last_circle + Vertical - 1, first_circle, last_circle])


def resetPoints(dt):
	global Points, P, Q, Vertical, Horizontal, heightOfParaboloid, vector, pos, border, figure, is_animated
	Points = (GLfloat * (Vertical * (2 * Horizontal - 1) * 3 + 6))()
	k = 0

	stepy = float(heightOfParaboloid) / Horizontal
	anglexz = 2 * pi / Vertical
	curangle = 0
	h = 0.0
	for i in range(Horizontal):
		h += stepy
		for j in range(Vertical):
			Points[k] = sqrt(2 * Q * h) * cos(curangle)
			Points[k + 1] = h - heightOfParaboloid / 2.0
			Points[k + 2] = sqrt(2 * P * h) * sin(curangle)
			k += 3
			curangle += anglexz
	Points[k], Points[k + 1], Points[k + 2] = 0.0, heightOfParaboloid / -2.0, 0.0
	k += 3

	stepy = float(heightOfParaboloid) / Horizontal
	anglexz = 2 * pi / Vertical
	curangle = 0
	h = 0.0
	for i in range(Horizontal - 1):
		h += stepy
		for j in range(Vertical):
			Points[k] = sqrt(2 * Q * h) * cos(curangle)
			Points[k + 1] = heightOfParaboloid / 2.0
			Points[k + 2] = sqrt(2 * P * h) * sin(curangle)
			k += 3
			curangle += anglexz
	Points[k], Points[k + 1], Points[k + 2] = 0.0, heightOfParaboloid / 2.0, 0.0

	# print(Points)

	if is_animated:
		if figure[0][0] > border[0][0] and figure[0][1] > border[0][1] and figure[0][2] > border[0][2] and figure[1][0] < border[1][0] and figure[1][1] < border[1][1] and figure[1][2] < border[1][2]:
			pos += vector
			figure += vector
		else:
			if figure[0][0] < border[0][0] or figure[1][0] > border[1][0]:
				vector[0] *= -1
			if figure[0][1] < border[0][1] or figure[1][1] > border[1][1]:
				vector[1] *= -1
			if figure[0][2] < border[0][2] or figure[1][2] > border[1][2]:
				vector[2] *= -1
			pos += vector
			figure += vector


@window.event
def on_draw():
	global Width, Height
	global ratio
	global isFramedMode
	global Horizontal, Vertical, heightOfParaboloid, P, Q
	global texture, chess
	global coordx, coordy, coordz, is_infinity_light, ambient_color, local_viewer, two_side, face, is_local, is_lighted, is_textured
	global ambient, diffuse, specular, shininess, emission, is_material
	global shaders
	window.clear()
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
	glEnable(GL_DEPTH_TEST)

	# if not is_textured:
	# 	glDisable(GL_TEXTURE_2D)
	#
	# if is_textured:
	# 	glEnable(texture.target)
	# 	glBindTexture(texture.target, texture.id)
	# 	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, chess.width, chess.height, 0, GL_RGBA, GL_UNSIGNED_BYTE, chess.get_data())
	# 	glEnable(GL_TEXTURE_2D)
	# 	glEnable(GL_NORMALIZE)
	#
	# if not is_lighted:
	# 	glDisable(GL_LIGHTING)
	#
	# if is_lighted:
	# 	glEnable(GL_LIGHTING)
	# 	glEnable(GL_LIGHT0)
	# 	if not is_material:
	# 		glEnable(GL_COLOR_MATERIAL)
	# 	else:
	# 		glDisable(GL_COLOR_MATERIAL)
	# 	glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE)
	# 	glLightiv(GL_LIGHT0, GL_POSITION, (GLint * 4)(coordx, coordy, coordz, is_infinity_light))
	#
	# 	glLightfv(GL_LIGHT0, GL_AMBIENT, (GLfloat * 4)(0.4, 0.4, 0.4, 1))
	# 	glLightfv(GL_LIGHT0, GL_DIFFUSE, (GLfloat * 4)(0.4, 0.4, 0.4, 1))
	# 	glLightfv(GL_LIGHT0, GL_SPECULAR, (GLfloat * 4)(0.4, 0.4, 0.4, 1))
	#
	# 	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambient_color)
	# 	if is_local:
	# 		glLightModelfv(GL_LIGHT_MODEL_LOCAL_VIEWER, local_viewer)
	# 	glLightModelfv(GL_LIGHT_MODEL_TWO_SIDE, two_side)
	#
	# 	if is_material:
	# 		glMaterialfv(face, GL_AMBIENT, ambient)
	# 		glMaterialfv(face, GL_DIFFUSE, diffuse)
	# 		glMaterialfv(face, GL_SPECULAR, specular)
	# 		glMaterialfv(face, GL_SHININESS, (GLfloat * 1)(shininess))
	# 		glMaterialfv(face, GL_EMISSION, emission)
	# 	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE)

	# ------------------------------------------------------------

	EllepticalParaboloid(isFramedMode)
	if isFramedMode:
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE)
	else:
		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL)
	shaders.use()
	glDrawElements(GL_TRIANGLES, len(indices), GL_UNSIGNED_INT, 0)


@window.event
def on_resize(width, height):
	global ratio
	glViewport(0, 0, width, height)
	ratio = width / height
	resetPoints(0)


@window.event
def on_mouse_press(x, y, button, modifiers):
	resetPoints(0)

	global isFramedMode
	if button == mouse.LEFT:
		isFramedMode = not isFramedMode


@window.event
def on_key_press(symbol, modifiers):
	global pos, rot, Horizontal, Vertical, shaders
	global speed, vector, is_infinity_light, two_side, face, is_local, is_animated, is_lighted, is_textured, is_material, scale

	if symbol == key.S:
		pos[1] -= 0.05
	elif symbol == key.W:
		pos[1] += 0.05
	elif symbol == key.D:
		pos[0] += 0.05
	elif symbol == key.A:
		pos[0] -= 0.05
	elif symbol == key.UP:
		pos[2] += 0.05
	elif symbol == key.DOWN:
		pos[2] -= 0.05
	elif symbol == key.Z:
		rot[0] -= 0.07
	elif symbol == key.X:
		rot[0] += 0.07
	elif symbol == key.C:
		rot[1] -= 0.07
	elif symbol == key.V:
		rot[1] += 0.07
	elif symbol == key.B:
		rot[2] -= 0.07
	elif symbol == key.N:
		rot[2] += 0.07

	elif symbol == key.O:
		Horizontal -= 1
	elif symbol == key.P:
		Horizontal += 1
	elif symbol == key.K:
		Vertical -= 1
	elif symbol == key.L:
		Vertical += 1

	elif symbol == key.Q:
		scale -= 0.1
	elif symbol == key.E:
		scale += 0.1

	elif symbol == key.R:
		is_material = not is_material
	elif symbol == key.T:
		is_infinity_light = not is_infinity_light
	elif symbol == key.U:
		if two_side[0] == 0:
			two_side[0] = 1
		elif two_side[0] == 1:
			two_side[0] = 0
	elif symbol == key.I:
		if face == GL_FRONT_AND_BACK:
			face = GL_FRONT
		elif face == GL_FRONT:
			face = GL_BACK
		elif face == GL_BACK:
			face = GL_FRONT_AND_BACK
	elif symbol == key.H:
		is_local = not is_local
	elif symbol == key.G:
		is_animated = not is_animated
	elif symbol == key.F:
		is_lighted = not is_lighted
	elif symbol == key.M:
		is_textured = not is_textured

	resetPoints(0)
	shaders.update()


resetPoints(0)
pyglet.clock.schedule_interval(resetPoints, 1.0 / 60)

cx = 11127
cy = 11127
cz = 11127
p = float(-1) / float(cx)
q = float(-1) / float(cy)
r = float(-1) / float(cz)
matrixShift = Matrix([(1, 0, 0, 0),
						  (0, 1, 0, 0),
						  (0, 0, 1, 0),
						  (0, 0.1, 0.35, 1)])
matrixPerspective = Matrix([(1, 0, 0, p),
								(0, 1, 0, q),
								(0, 1, 0, r),
								(0, 0, 0, 1)])
matrixProjection = Matrix([(1, 0, 0, 0),
							   (0, 1, 0, 0),
							   (0, 0, 0, 0),
							   (0, 0, 0, 1)])
matrixFinal = matrixProjection @ matrixPerspective @ matrixShift
Matrix.transpose(matrixFinal)
value = (GLfloat * 16)()
for i in range(4):
	for j in range(4):
		value[i * 4 + j] = matrixFinal[i][j]
shaders.projection(value)

pyglet.app.run()
