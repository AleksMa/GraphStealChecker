import codecs
import ctypes
import time
from math import pi, sin, cos

import numpy
from pyglet.gl import *
import pyglet
from pyglet.window import key

try:
    # Try and create a window with multisampling (antialiasing)
    config = Config(sample_buffers=1, samples=4,
                    depth_size=16, double_buffer=True, )
    window = pyglet.window.Window(resizable=True, config=config)
except pyglet.window.NoSuchConfigException:
    # Fall back to no multisampling for old hardware
    window = pyglet.window.Window(resizable=True)

stop = False
spin = True
show_tex = True
show_light = True

@window.event
def on_resize(width, height):
    glViewport(0, 0, width, height)
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    gluPerspective(60., width / float(height), .1, 1000.)
    glMatrixMode(GL_MODELVIEW)
    return pyglet.event.EVENT_HANDLED

def vec(*args):
    return (GLfloat * len(args))(*args)

fill = True
painted_box = GL_LINE
colors_box = [[0.8, 0.7, 0.1], [0.25, 0.5, 0.25], [0.4, 0.3, 0.9], [0.1, 0.1, 0.55], [0.6, 0.3, 0.9], [0.75, 0.5, 0.65]]
ambient = vec(1, 1, 1, 1)
diffuse = vec(1, 1, 1, 1)
specular  = vec(1, 1, 1, 1)


alfa = 5
@window.event
def on_key_press(symbol, modifiers):
    global rx, ry, rz, fill, ambient, diffuse, specular, stop, spin, show_tex, show_light
    if symbol == key.Q:
        rx += alfa
    elif symbol == key.W:
        rx -= alfa
    elif symbol == key.A:
        ry += alfa
    elif symbol == key.S:
        ry -= alfa
    elif symbol == key.Z:
        rz += alfa
    elif symbol == key.X:
        rz -= alfa
    elif symbol == key.SPACE:
        fill = not fill
    elif symbol == key._1:
        r = (ambient[0] + 1) % 2
        g = ambient[1]
        b = ambient[2]
        ambient = vec(r, g, b, 1)
    elif symbol == key._2:
        g = (ambient[1] + 1) % 2
        r = ambient[0]
        b = ambient[2]
        ambient = vec(r, g, b, 1)
    elif symbol == key._3:
        b = (ambient[2] + 1) % 2
        g = ambient[1]
        r = ambient[0]
        ambient = vec(r, g, b, 1)
    elif symbol == key._4:
        r = (diffuse[0] + 1) % 2
        g = diffuse[1]
        b = diffuse[2]
        diffuse = vec(r, g, b, 1)
    elif symbol == key._5:
        g = (diffuse[1] + 1) % 2
        r = diffuse[0]
        b = diffuse[2]
        diffuse = vec(r, g, b, 1)
    elif symbol == key._6:
        b = (diffuse[2] + 1) % 2
        g = diffuse[1]
        r = diffuse[0]
        diffuse = vec(r, g, b, 1)
    elif symbol == key._7:
        r = (specular[0] + 1) % 2
        g = specular[1]
        b = specular[2]
        specular = vec(r, g, b, 1)
    elif symbol == key._8:
        g = (specular[1] + 1) % 2
        r = specular[0]
        b = specular[2]
        specular = vec(r, g, b, 1)
    elif symbol == key._9:
        b = (specular[2] + 1) % 2
        g = specular[1]
        r = specular[0]
        specular = vec(r, g, b, 1)
    elif symbol == key.ENTER:
        stop = not stop
    elif symbol == key.K:
        spin = not spin
    elif symbol == key.T:
        show_tex = not show_tex
    elif symbol == key.L:
        show_light = not show_light
    print('abmbient ', *ambient)
    print('diffuse ', *diffuse)
    print('specular ', *specular)
    print()
    setup()


def update(dt):
    if not stop:
        torus.intersection_with_box(box)
        for i in range(3): torus.cur_pos[i] += torus.speed_vec[i]
    if spin:
        dt = dt
        global rx, ry, rz
        rx += dt * 1
        ry += dt * 80
        rz += dt * 30
        rx %= 360
        ry %= 360
        rz %= 360


pyglet.clock.schedule(update)


@window.event
def on_draw():
    t1 = time.time()
    # if show_tex:
    #     glEnable(GL_TEXTURE_2D)
    # else:
    #     glDisable(GL_TEXTURE_2D)
    if show_light:
        glEnable(GL_LIGHTING)
    else:
        glDisable(GL_LIGHTING)
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    load_textures()
    glMatrixMode(GL_MODELVIEW)
    if not fill:
        glPolygonMode(GL_FRONT_AND_BACK, GL_LINE)
    else:
        glPolygonMode(GL_FRONT_AND_BACK, GL_FILL)
    glLoadIdentity()
    glPushMatrix()
    glTranslatef(0+torus.cur_pos[0], 0+torus.cur_pos[1], -4+torus.cur_pos[2])
    glRotatef(rz, 0, 0, 1)
    glRotatef(ry, 0, 1, 0)
    glRotatef(rx, 1, 0, 0)
    torus.draw()
    glPopMatrix()
    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()
    glPushMatrix()
    glTranslatef(0, 0, -4)
    box.draw()
    glPopMatrix()
    save()
    t2 = time.time()
    print(t2-t1)

def setup_light():
    glEnable(GL_LIGHT0)
    #glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE)
    glLightfv(GL_LIGHT0, GL_POSITION, vec(-10, 5, 1, 0))
    glLightfv(GL_LIGHT0, GL_SPECULAR, specular)  # цвет блика
    glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse)  # как фонарик, цвет света
    glLightfv(GL_LIGHT0, GL_AMBIENT, ambient)  # фоновый

    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, vec(0.1, 0.1, 0.1, 1))
    glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, vec(1, 0.8, 1, 1))
    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, vec(1, 1, 1, 1))
    glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, 128)  # ширина бликов 128 - маленький, 1 - большой


def setup():
    glClearColor(0.3, 0.3, 0.3, 1)
    glColor3f(1, 1, 1)
    glEnable(GL_DEPTH_TEST)
    if show_tex:
        glEnable(GL_TEXTURE_2D)
    else:
        glDisable(GL_TEXTURE_2D)
    if show_light:
        glEnable(GL_LIGHTING)
    else:
        glDisable(GL_LIGHTING)
    setup_light()


class Box:
    def __init__(self, q=1.5):
        self.q = q
        self.min_box = [-q, -q, -q]
        self.max_box = [q, q, q]
        lbf = 0
        rbf = 1
        rtf = 2
        ltf = 3
        lbn = 4
        rbn = 5
        rtn = 6
        ltn = 7
        self.list = glGenLists(1)
        vertices = list()
        vertices.extend([-q, -q, -q])
        vertices.extend([q, -q, -q])
        vertices.extend([q, q, -q])
        vertices.extend([-q, q, -q])
        vertices.extend([-q, -q, q])
        vertices.extend([q, -q, q])
        vertices.extend([q, q, q])
        vertices.extend([-q, q, q])
        indices = list()
        indices.extend([lbn, lbf, rbf, rbn])
        indices.extend([lbf, ltf, rtf, rbf])
        indices.extend([lbn, lbf, ltf, ltn])
        indices.extend([rbn, rbf, rtf, rtn])
        indices.extend([ltn, ltf, rtf, rtn])
        indices.extend([lbn, ltn, rtn, rbn])
        colors = list()
        for i in range(6): colors.extend([*colors_box[i]])
        indices = (GLuint * len(indices))(*indices)
        vertices = (GLfloat * len(vertices))(*vertices)
        colors = (GLfloat * len(colors))(*colors)
        glNewList(self.list, GL_COMPILE)
        glPolygonMode(GL_FRONT_AND_BACK, GL_LINE)
        glPushClientAttrib(GL_CLIENT_VERTEX_ARRAY_BIT)
        glEnableClientState(GL_VERTEX_ARRAY)
        glEnableClientState(GL_COLOR_ARRAY)
        glVertexPointer(3, GL_FLOAT, 0, vertices)
        glColorPointer(3, GL_FLOAT, 0, colors)
        glDrawElements(GL_QUADS, len(indices), GL_UNSIGNED_INT, indices)
        glPopClientAttrib()
        glEndList()
    def draw(self):
        glCallList(self.list)

class Torus:
    def __init__(self, radius, inner_radius, slices, inner_slices, speed_vec):
        vertices = list()
        normals = list()
        ver = []
        self.speed_vec = speed_vec

        u_step = 2 * pi / (slices - 1)
        v_step = 2 * pi / (inner_slices - 1)
        u = pi
        for i in range(slices):
            cos_u = cos(u)
            sin_u = sin(u)
            v = pi
            for j in range(inner_slices):
                cos_v = cos(v)
                sin_v = sin(v)

                d = (radius + inner_radius * cos_v)
                x = d * cos_u
                y = d * sin_u
                z = inner_radius * sin_v

                nx = cos_u * cos_v
                ny = sin_u * cos_v
                nz = sin_v
                k = 2
                vertices.extend([x/k, y/k, z/k])
                ver.append([x/k, y/k, z/k])
                normals.extend([nx, ny, nz])
                v += v_step
            u += u_step

        np_ar = numpy.array(ver)
        self.max_torus = numpy.amax(np_ar, axis=0)
        self.min_torus = numpy.amin(np_ar, axis=0)

        self.cur_pos = [0, 0, 0]

        texture = list()
        div_x = numpy.linspace(0, 1, slices)
        div_y = numpy.linspace(0, 1, inner_slices)
        for i in range(len(div_x)):
            for j in range(len(div_y)):
                texture.extend([div_x[i], div_y[j]])


        indices = list()
        for i in range(slices - 1):
            for j in range(inner_slices - 1):
                p = i * inner_slices + j
                indices.extend([p, p + inner_slices, p + inner_slices + 1])
                indices.extend([p, p + inner_slices + 1, p + 1])


        indices = (GLuint * len(indices))(*indices)
        vertices = (GLfloat * len(vertices))(*vertices)
        normals = (GLfloat * len(normals))(*normals)
        texture = (GLfloat * len(texture))(*texture)



        self.list = glGenLists(1)
        glNewList(self.list, GL_COMPILE)
        glPushClientAttrib(GL_CLIENT_VERTEX_ARRAY_BIT)
        glEnableClientState(GL_VERTEX_ARRAY)
        glEnableClientState(GL_NORMAL_ARRAY)
        glEnableClientState(GL_TEXTURE_COORD_ARRAY)
        glVertexPointer(3, GL_FLOAT, 0, vertices)
        glNormalPointer(GL_FLOAT, 0, normals)
        glTexCoordPointer(2, GL_FLOAT, 0, texture)
        glDrawElements(GL_TRIANGLES, len(indices), GL_UNSIGNED_INT, indices)
        glPopClientAttrib()
        glEndList()
    def draw(self):
        glCallList(self.list)
    def intersection_with_box(self, box):
        max_torus = self.max_torus
        min_torus = self.min_torus
        max_box = box.max_box
        min_box = box.min_box
        cur = self.cur_pos

        for i in range(3):
            if cur[i] + max_torus[i] >= max_box[i]:
                self.speed_vec[i] *= -1
        for i in range(3):
            if cur[i] + min_torus[i] <= min_box[i]:
                self.speed_vec[i] *= -1

textures = GLuint()

def load_textures():
    img = pyglet.image.load('cake.bmp')
    glGenTextures(1, ctypes.pointer(textures))
    glBindTexture(GL_TEXTURE_2D, textures)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
    # glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE)
    # glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE)
    # glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE)
    data = img._current_data
    glTexImage2D(GL_TEXTURE_2D, 0, 3, img.width, img.height, 0, GL_BGR, GL_UNSIGNED_BYTE, data)

def open_save():
    f = open('save.txt', 'r')
    text = f.read()
    param = text.split('\n')
    torus.cur_pos = [float(param[0]), float(param[1]), float(param[2])]
    global rx, ry, rz, show_tex, show_light, spin
    rx = float(param[3])
    ry = float(param[4])
    rz = float(param[5])
    if param[6] == 'True':
        show_tex = True
    else:
        show_tex = False
    if param[7] == 'True':
        show_light = True
    else:
        show_light = False
    if param[8] == 'True':
        spin = True
    else:
        spin = False


def save():
    f = open('save.txt', 'w')
    f.write(str(torus.cur_pos[0])+'\n')
    f.write(str(torus.cur_pos[1]) + '\n')
    f.write(str(torus.cur_pos[2]) + '\n')
    f.write(str(rx) + '\n')
    f.write(str(ry) + '\n')
    f.write(str(rz) + '\n')
    f.write(str(show_tex)+'\n')
    f.write(str(show_light)+'\n')
    f.write(str(spin)+'\n')


setup()
glDisable(GL_TEXTURE_2D)
box = Box()
torus = Torus(1, 0.8, 50, 30, speed_vec=[0.05, 0.02, 0.03])
rx = ry = rz = 0
open_save()
pyglet.app.run()