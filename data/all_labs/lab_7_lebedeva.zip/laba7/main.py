import ctypes
import time
from math import pi, sin, cos

import numpy
from pyglet.gl import *
import pyglet
from pyglet.window import key

config = Config(sample_buffers=1, samples=4,
                    depth_size=16, double_buffer=True, )
window = pyglet.window.Window(resizable=True, config=config)
glClearColor(0.3, 0.3, 0.3, 1)
glEnable(GL_DEPTH_TEST)


@window.event
def on_resize(width, height):
    glViewport(0, 0, width, height)
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    gluPerspective(60., width / float(height), .1, 1000.)
    glMatrixMode(GL_MODELVIEW)
    return pyglet.event.EVENT_HANDLED

def vec(*args):
    return (GLfloat * len(args))(*args)



ambient = vec(1, 1, 1, 1)
diffuse = vec(1, 1, 1, 1)
specular  = vec(1, 1, 1, 1)



@window.event
def on_key_press(symbol, modifiers):
    alfa = 5
    global rx, ry, rz, ambient, diffuse, specular
    if symbol == key.Q:
        torus.rx += alfa
    elif symbol == key.W:
        torus.rx -= alfa
    elif symbol == key.A:
        torus.ry += alfa
    elif symbol == key.S:
        torus.ry -= alfa
    elif symbol == key.Z:
        torus.rz += alfa
    elif symbol == key.X:
        torus.rz -= alfa
    elif symbol == key.SPACE:
        torus.fill = not torus.fill
    elif symbol == key._1:
        r = (ambient[0] + 1) % 2
        g = ambient[1]
        b = ambient[2]
        ambient = vec(r, g, b, 1)
    elif symbol == key._2:
        g = (ambient[1] + 1) % 2
        r = ambient[0]
        b = ambient[2]
        ambient = vec(r, g, b, 1)
    elif symbol == key._3:
        b = (ambient[2] + 1) % 2
        g = ambient[1]
        r = ambient[0]
        ambient = vec(r, g, b, 1)
    elif symbol == key._4:
        r = (diffuse[0] + 1) % 2
        g = diffuse[1]
        b = diffuse[2]
        diffuse = vec(r, g, b, 1)
    elif symbol == key._5:
        g = (diffuse[1] + 1) % 2
        r = diffuse[0]
        b = diffuse[2]
        diffuse = vec(r, g, b, 1)
    elif symbol == key._6:
        b = (diffuse[2] + 1) % 2
        g = diffuse[1]
        r = diffuse[0]
        diffuse = vec(r, g, b, 1)
    elif symbol == key._7:
        r = (specular[0] + 1) % 2
        g = specular[1]
        b = specular[2]
        specular = vec(r, g, b, 1)
    elif symbol == key._8:
        g = (specular[1] + 1) % 2
        r = specular[0]
        b = specular[2]
        specular = vec(r, g, b, 1)
    elif symbol == key._9:
        b = (specular[2] + 1) % 2
        g = specular[1]
        r = specular[0]
        specular = vec(r, g, b, 1)
    elif symbol == key.ENTER:
        torus.stop = not torus.stop
    elif symbol == key.K:
        torus.spin = not torus.spin
    elif symbol == key.T:
        torus.show_tex = not torus.show_tex
    elif symbol == key.L:
        torus.show_light = not torus.show_light
    elif symbol == key.C: # сохранить текущее положение
        save()
    elif symbol == key.O: # октрыть сохраненное состояние
        open_save()
    if (symbol == key._1 or symbol == key._2 or symbol == key._3 or symbol == key._4 or symbol == key._5
        or symbol == key._6 or symbol == key._7 or symbol == key._8 or symbol == key._9):
        print('abmbient ', *ambient)
        print('diffuse ', *diffuse)
        print('specular ', *specular)
        print()
        setup_light()


def update(dt):
    if not torus.stop:
        torus.intersection_with_box(box)
        for i in range(3): torus.cur_pos[i] += torus.speed_vec[i]
    if torus.spin:
        dt = dt
        torus.rx += dt * 1
        torus.ry += dt * 80
        torus.rz += dt * 30
        torus.rx %= 360
        torus.ry %= 360
        torus.rz %= 360


pyglet.clock.schedule(update)


@window.event
def on_draw():
    t1 = time.time()
    if torus.show_tex: glEnable(GL_TEXTURE_2D)
    else: glDisable(GL_TEXTURE_2D)
    if torus.show_light: glEnable(GL_LIGHTING)
    else: glDisable(GL_LIGHTING)
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glMatrixMode(GL_MODELVIEW)
    if not torus.fill:
        glPolygonMode(GL_FRONT_AND_BACK, GL_LINE)
    else:
        glPolygonMode(GL_FRONT_AND_BACK, GL_FILL)
    glLoadIdentity()
    glPushMatrix()
    glTranslatef(0+torus.cur_pos[0], 0+torus.cur_pos[1], -4+torus.cur_pos[2])
    glRotatef(torus.rz, 0, 0, 1)
    glRotatef(torus.ry, 0, 1, 0)
    glRotatef(torus.rx, 1, 0, 0)
    torus.draw()
    glPopMatrix()
    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()
    glPushMatrix()
    glTranslatef(0, 0, -4)
    box.draw()
    glPopMatrix()
    t2 = time.time()
    print(t2-t1)

def setup_light():
    glEnable(GL_LIGHT0)
    #glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE)
    glLightfv(GL_LIGHT0, GL_POSITION, vec(-10, 5, 1, 0))
    glLightfv(GL_LIGHT0, GL_SPECULAR, specular)  # цвет блика
    glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse)  # как фонарик, цвет света
    glLightfv(GL_LIGHT0, GL_AMBIENT, ambient)  # фоновый

    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, vec(0.1, 0.1, 0.1, 1))
    glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, vec(1, 0.8, 1, 1))
    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, vec(1, 1, 1, 1))
    glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, 128)  # ширина бликов 128 - маленький, 1 - большой





class Box:
    def __init__(self, q=1.5):
        self.q = q
        self.min_box = [-q, -q, -q]
        self.max_box = [q, q, q]
        colors_box = [[0.8, 0.7, 0.1], [0.25, 0.5, 0.25], [0.4, 0.3, 0.9], [0.1, 0.1, 0.55], [0.6, 0.3, 0.9],
                      [0.75, 0.5, 0.65]]
        lbf = 0
        rbf = 1
        rtf = 2
        ltf = 3
        lbn = 4
        rbn = 5
        rtn = 6
        ltn = 7
        self.list = glGenLists(1)
        vertices = list()
        vertices.extend([-q, -q, -q])
        vertices.extend([q, -q, -q])
        vertices.extend([q, q, -q])
        vertices.extend([-q, q, -q])
        vertices.extend([-q, -q, q])
        vertices.extend([q, -q, q])
        vertices.extend([q, q, q])
        vertices.extend([-q, q, q])
        indices = list()
        indices.extend([lbn, lbf, rbf, rbn])
        indices.extend([lbf, ltf, rtf, rbf])
        indices.extend([lbn, lbf, ltf, ltn])
        indices.extend([rbn, rbf, rtf, rtn])
        indices.extend([ltn, ltf, rtf, rtn])
        indices.extend([lbn, ltn, rtn, rbn])
        colors = list()
        for i in range(6): colors.extend([*colors_box[i]])
        indices = (GLuint * len(indices))(*indices)
        vertices = (GLfloat * len(vertices))(*vertices)
        colors = (GLfloat * len(colors))(*colors)
        glNewList(self.list, GL_COMPILE)
        glPolygonMode(GL_FRONT_AND_BACK, GL_LINE)
        glPushClientAttrib(GL_CLIENT_VERTEX_ARRAY_BIT)
        glEnableClientState(GL_VERTEX_ARRAY)
        glEnableClientState(GL_COLOR_ARRAY)
        glVertexPointer(3, GL_FLOAT, 0, vertices)
        glColorPointer(3, GL_FLOAT, 0, colors)
        glDrawElements(GL_QUADS, len(indices), GL_UNSIGNED_INT, indices)
        glPopClientAttrib()
        glEndList()
    def draw(self):
        glCallList(self.list)

class Torus:
    def __init__(self, radius, inner_radius, slices, inner_slices, speed_vec):
        vertices = list()
        normals = list()
        ver = []
        self.speed_vec = speed_vec
        self.rx = 0
        self.ry = 0
        self.rz = 0
        self.spin = True
        self.stop = False
        self.show_tex = True
        self.show_light = True
        self.fill = True
        self.cur_pos = [0, 0, 0]

        u_step = 2 * pi / (slices - 1)
        v_step = 2 * pi / (inner_slices - 1)
        u = pi
        for i in range(slices):
            cos_u = cos(u)
            sin_u = sin(u)
            v = pi
            for j in range(inner_slices):
                cos_v = cos(v)
                sin_v = sin(v)

                d = (radius + inner_radius * cos_v)
                x = d * cos_u
                y = d * sin_u
                z = inner_radius * sin_v

                nx = cos_u * cos_v
                ny = sin_u * cos_v
                nz = sin_v
                k = 2
                vertices.extend([x/k, y/k, z/k])
                ver.append([x/k, y/k, z/k])
                normals.extend([nx, ny, nz])
                v += v_step
            u += u_step

        np_ar = numpy.array(ver)
        self.max_torus = numpy.amax(np_ar, axis=0)
        self.min_torus = numpy.amin(np_ar, axis=0)


        texture = list()
        div_x = numpy.linspace(0, 1, slices)
        div_y = numpy.linspace(0, 1, inner_slices)
        for i in range(len(div_x)):
            for j in range(len(div_y)):
                texture.extend([div_x[i], div_y[j]])

        indices = list()
        for i in range(slices - 1):
            for j in range(inner_slices - 1):
                p = i * inner_slices + j
                indices.extend([p, p + inner_slices, p + inner_slices + 1])
                indices.extend([p, p + inner_slices + 1, p + 1])


        indices = (GLuint * len(indices))(*indices)
        vertices = (GLfloat * len(vertices))(*vertices)
        normals = (GLfloat * len(normals))(*normals)
        texture = (GLfloat * len(texture))(*texture)

        self.list = glGenLists(1)
        glNewList(self.list, GL_COMPILE)
        glPushClientAttrib(GL_CLIENT_VERTEX_ARRAY_BIT)
        glEnableClientState(GL_VERTEX_ARRAY)
        glEnableClientState(GL_NORMAL_ARRAY)
        glEnableClientState(GL_TEXTURE_COORD_ARRAY)
        glVertexPointer(3, GL_FLOAT, 0, vertices)
        glNormalPointer(GL_FLOAT, 0, normals)
        glTexCoordPointer(2, GL_FLOAT, 0, texture)
        glDrawElements(GL_TRIANGLES, len(indices), GL_UNSIGNED_INT, indices)
        glPopClientAttrib()
        glEndList()
    def draw(self):
        glCallList(self.list)
    def intersection_with_box(self, box):
        max_torus = self.max_torus
        min_torus = self.min_torus
        max_box = box.max_box
        min_box = box.min_box
        cur = self.cur_pos

        for i in range(3):
            if cur[i] + max_torus[i] >= max_box[i]:
                self.speed_vec[i] *= -1
        for i in range(3):
            if cur[i] + min_torus[i] <= min_box[i]:
                self.speed_vec[i] *= -1



def load_textures():
    img = pyglet.image.load('cake.bmp')
    textures = GLuint()
    glGenTextures(1, ctypes.pointer(textures))
    glBindTexture(GL_TEXTURE_2D, textures)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
    # glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE)
    data = img._current_data
    glTexImage2D(GL_TEXTURE_2D, 0, 3, img.width, img.height, 0, GL_BGR, GL_UNSIGNED_BYTE, data)

def open_save():
    f = open('save.txt', 'r')
    text = f.read()
    param = text.split('\n')
    torus.cur_pos = [float(param[0]), float(param[1]), float(param[2])]
    torus.rx = float(param[3])
    torus.ry = float(param[4])
    torus.rz = float(param[5])
    if param[6] == 'True':
        torus.show_tex = True
    else:
        torus.show_tex = False
    if param[7] == 'True':
        torus.show_light = True
    else:
        torus.show_light = False
    if param[8] == 'True':
        torus.spin = True
    else:
        torus.spin = False
    if param[9] == 'True':
        torus.stop = True
    else:
        torus.stop = False
    torus.speed_vec = [float(param[10]), float(param[11]), float(param[12])]


def save():
    f = open('save.txt', 'w')
    f.write(str(torus.cur_pos[0])+'\n')
    f.write(str(torus.cur_pos[1]) + '\n')
    f.write(str(torus.cur_pos[2]) + '\n')
    f.write(str(torus.rx) + '\n')
    f.write(str(torus.ry) + '\n')
    f.write(str(torus.rz) + '\n')
    f.write(str(torus.show_tex)+'\n')
    f.write(str(torus.show_light)+'\n')
    f.write(str(torus.spin)+'\n')
    f.write(str(torus.stop)+'\n')
    # f.write(str(torus.speed_vec[0])+'\n')
    # f.write(str(torus.speed_vec[1])+'\n')
    # f.write(str(torus.speed_vec[2])+'\n')


setup_light()
# glDisable(GL_TEXTURE_2D)
load_textures()
box = Box()
torus = Torus(1, 0.8, 50, 30, speed_vec=[0.05, 0.02, 0.03])
pyglet.app.run()